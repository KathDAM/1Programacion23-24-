package vectores;

public interface lect {

}
